

//Class that will hold the edges from the source to its adjacent nodes
public class Edge
{
    private Vertex source;
    private Vertex destination;
    private int travelTime;
    private int travelCost;
    private int weight;
    private String travelMode;

    public Edge(Vertex source, Vertex destination, int flightTime, int flightCost, int weight, String travelMode) {
        this.source = source;
        this.destination = destination;
        this.travelTime = flightTime;
        this.travelCost = flightCost;
        this.weight = weight;
        this.travelMode = travelMode;
    }

    public Vertex getDestination() {
        return destination;
    }

    public void setDestination(Vertex destination) {
        this.destination = destination;
    }

    public int getTravelTime() {
        return travelTime;
    }

    public void setTravelTime(int travelTime) {
        this.travelTime = travelTime;
    }

    public int getTravelCost() {
        return travelCost;
    }

    public void setTravelCost(int travelCost) {
        this.travelCost = travelCost;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public Vertex getSource() {
        return source;
    }

    public void setSource(Vertex source) {
        this.source = source;
    }


    public String getTravelMode() {
        return travelMode;
    }

    public void setTravelMode(String travelMode) {
        this.travelMode = travelMode;
    }
}
