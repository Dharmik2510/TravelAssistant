import java.util.HashMap;

//Class that will hold all the vertexes of the graph
//In our case it will be cities added by addCity() method
public class Vertex
{
    String cityName;
    Boolean testRequired;
    int timeToTest;
    int nightlyHotelCost;
    String travelMode;
    HashMap<Integer,String> weightToTravelMode = new HashMap<>();


    public Vertex(String cityName, Boolean testRequired, int timeToTest, int nightlyHotelCost) {
        this.cityName = cityName;
        this.testRequired = testRequired;
        this.timeToTest = timeToTest;
        this.nightlyHotelCost = nightlyHotelCost;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public Boolean getTestRequired() {
        return testRequired;
    }

    public void setTestRequired(Boolean testRequired) {
        this.testRequired = testRequired;
    }

    public int getTimeToTest() {
        return timeToTest;
    }

    public void setTimeToTest(int timeToTest) {
        this.timeToTest = timeToTest;
    }

    public int getNightlyHotelCost() {
        return nightlyHotelCost;
    }

    public void setNightlyHotelCost(int nightlyHotelCost) {
        this.nightlyHotelCost = nightlyHotelCost;
    }

    public void setWeightToTravelMode(int weight, String travelMode)
    {
        weightToTravelMode.put(weight,travelMode);
    }

    public HashMap<Integer,String> getWeightToTravelMode()
    {
        return this.weightToTravelMode;
    }

    public String getTravelMode() {
        return travelMode;
    }

    public void setTravelMode(String travelMode) {
        this.travelMode = travelMode;
    }


}
