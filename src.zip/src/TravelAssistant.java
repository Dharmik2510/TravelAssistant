import java.util.*;

public class TravelAssistant
{

    //HashMap that will hold whole graph as an adjacencyList
    private final Map<Vertex, List<Edge>> adjVertices = new HashMap<>();

    //Mapping city name to its object(Vertex)
    private final Map<String,Vertex> nameToVertex = new HashMap<>();

    private ArrayList<Edge> adjCityList = new ArrayList<>();

    //List of vertexes
    private final List<Vertex> nodes = new ArrayList<>();

    //List of edges
    private final List<Edge> edges = new ArrayList<>();


    //Indicate that a particular city is a possible starting point or destination in the travel plans
    private void addCity(String cityName, boolean testRequired, int timetoTest, int nightlyhotelCost)
    {
        if(cityName==null || cityName.isEmpty() || nightlyhotelCost<0 )
        {
            throw new IllegalArgumentException("input parameters are unacceptable");
        }
        else if(nameToVertex.get(cityName)==null)
        {
            Vertex vertex = new Vertex(cityName,testRequired,timetoTest,nightlyhotelCost);
            nodes.add(vertex);
            nameToVertex.putIfAbsent(cityName,vertex);
            adjVertices.putIfAbsent(vertex,new ArrayList<>());
            System.out.println("City can now be used in the TA");
        }
        else
        {
            System.out.println("City already present in the system");
        }


    }

    //Record the existence of a one-way flight from the startCity to the destinationCity.
    private int addFlight(String startCity, String destinationCity, int flightTime, int flightCost) throws IllegalArgumentException
    {
        Vertex startCityVertex = nameToVertex.get(startCity);
        Vertex  destCityVertex = nameToVertex.get(destinationCity);
        adjCityList = (ArrayList<Edge>) adjVertices.get(startCityVertex);
        Edge edge = new Edge(startCityVertex,destCityVertex,flightTime,flightCost,0,"flight");
        adjCityList.add(edge);
        //adjVertices.put(startCityVertex,adjCityList);
        return adjCityList.size();
    }


    private int addTrain( String startCity, String destinationCity, int trainTime, int trainCost)
    {
        Vertex startCityVertex = nameToVertex.get(startCity);
        Vertex destinationVertex = nameToVertex.get(destinationCity);
        adjCityList = (ArrayList<Edge>) adjVertices.get(startCityVertex);
        Edge edge = new Edge(startCityVertex,destinationVertex,trainTime,trainCost,0,"train");
        adjCityList.add(edge);
        return adjCityList.size();

    }


    // To Determine the sequence of plane, train, and city stays needed to travel from the startCity to the
    //destinationCity
    private void planTrip(String startCity, String DestinationCity, boolean isVaccinated, int costImp, int travelImp, int travelHopImp)
    {
        Vertex startCityVertex = nameToVertex.get(startCity);
        Vertex destinationVertex = nameToVertex.get(DestinationCity);
        for(Map.Entry<Vertex,List<Edge>> mapEntry:adjVertices.entrySet())
        {
            List<Edge> edgeList = adjVertices.get(mapEntry.getKey());
            for(Edge edge: edgeList)
            {

                try {
                    int weight = calculateWeightOfEdge(edge.getTravelCost(),edge.getTravelTime(),costImp,travelImp,travelHopImp);
                    System.out.println("weight of " + edge.getDestination().getCityName() + " is:" + weight + "from source " + edge.getSource().getCityName()  +" for travel mode: " + edge.getTravelMode());
                    edge.setWeight(weight);
                    edge.getDestination().setWeightToTravelMode(weight,edge.getTravelMode());
                    edges.add(edge);
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }

            }

        }

        Graph graph = new Graph(nodes, edges);
        DijkstraAlgorithm dijkstra = new DijkstraAlgorithm(graph);
        int index = nodes.indexOf(startCityVertex);
        int destinationIndex = nodes.indexOf(destinationVertex);
        dijkstra.execute(nodes.get(index));

        LinkedList<Vertex> path = dijkstra.getPath(nodes.get(destinationIndex));

        for (Vertex vertex : path) {

            if(vertex.getTravelMode()==null)
            {
                System.out.print(vertex.getCityName() +" ( start ) " );
            }
            else
            {
                System.out.print(vertex.getCityName() + " ( " + vertex.getTravelMode() + " ) ");
            }



        }
        System.out.println();
    }


    //Calculating edge weight according to given user inputs( travelImportances)
    private int calculateWeightOfEdge(int flightCost, int flightTime, int costImp, int travelImp, int travelHopImp)
    {
        return (flightCost * costImp)  + ( flightTime * travelImp ) + (travelHopImp);
    }


    public static void main(String[] args) throws IllegalArgumentException {

        TravelAssistant grapgBuilding = new TravelAssistant();
        grapgBuilding.addCity("A",true,2,200);
        grapgBuilding.addCity("B",true,2,500);
        grapgBuilding.addCity("C",true,5,500);


        grapgBuilding.addFlight("A","B",2,2);
        grapgBuilding.addFlight("B","C",4,6);
        grapgBuilding.addFlight("A","C",8,10);

        grapgBuilding.addTrain("A","B",1,1);
        grapgBuilding.addTrain("A","C",5,10);



/*
        grapgBuilding.addFlight("A","B",2,2);
        grapgBuilding.addFlight("B","C",4,6);
        grapgBuilding.addFlight("A","C",8,10);

        grapgBuilding.addTrain("B","C",1,1);*/



        grapgBuilding.planTrip("A","C",true,1,1,1);

    }


}
